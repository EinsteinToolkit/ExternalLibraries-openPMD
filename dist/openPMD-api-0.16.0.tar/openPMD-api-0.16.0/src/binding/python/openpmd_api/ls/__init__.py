__doc__ = "for usage documentation, call this module's main with --help"
